import React from 'react';
import { Star, ShieldCheck, Quote } from 'lucide-react';

export const ReviewsSection = () => {
  const reviews = [
    {
      name: 'Михаил Сергеев',
      role: 'Advanced Open Water Diver',
      dives: '48 погружений',
      rating: 5,
      text: 'Поездка на Красное море с инструкторами Aqua Sphere перевернула мое представление о дайвинге. Полное ощущение невесомости, безупречный инструктаж и максимальное внимание к безопасности каждого студента.',
      date: 'Сентябрь 2025',
    },
    {
      name: 'Елена Васильева',
      role: 'Open Water Diver (PADI)',
      dives: '14 погружений',
      rating: 5,
      text: 'Начинала обучение с нуля в глубоководном бассейне клуба. Очень терпеливые инструкторы, первоклассное снаряжение Scubapro. Уже через 2 недели я уверенно парила над рифами Дахаба!',
      date: 'Август 2025',
    },
    {
      name: 'Артем Дмитриев',
      role: 'Deep & Wreck Explorer',
      dives: '120+ погружений',
      rating: 5,
      text: 'Экспедиция к затонувшим кораблям Черного моря — это незабываемо. Профессиональный расчет декомпрессии, газовая смесь Nitrox и высочайший уровень организации. Рекомендую Aqua Sphere всем!',
      date: 'Июль 2025',
    },
  ];

  return (
    <section id="reviews" className="reviews-section" style={{ position: 'relative', padding: '7rem 0', zIndex: 6 }}>
      <div className="container">
        <div style={{ textAlign: 'center', maxWidth: '720px', margin: '0 auto 3.5rem auto' }}>
          <span className="section-tag">ВПЕЧАТЛЕНИЯ ДАЙВЕРОВ</span>
          <h2 className="section-title">Истории Погружений</h2>
          <div className="pink-divider" style={{ width: '100px', margin: '1.2rem auto' }} />
          <p style={{ color: '#C0D5EC', fontSize: '1.05rem', fontWeight: 300 }}>
            Более 3,800 выпускников нашего клуба открыли для себя глубины морей и океанов.
            Вот что они говорят о своем опыте с нами.
          </p>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '2rem',
          }}
        >
          {reviews.map((rev, idx) => (
            <div
              key={idx}
              className="glass-panel"
              style={{
                padding: '2.2rem 2rem',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                position: 'relative',
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.2rem' }}>
                  <div style={{ display: 'flex', gap: '0.25rem' }}>
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} size={16} fill="#F05DBD" color="#F05DBD" />
                    ))}
                  </div>
                  <Quote size={24} color="rgba(39, 200, 245, 0.4)" />
                </div>

                <p style={{ color: '#D3E5F8', fontSize: '0.98rem', lineHeight: 1.75, marginBottom: '1.5rem', fontStyle: 'italic' }}>
                  «{rev.text}»
                </p>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingTop: '1.2rem',
                  borderTop: '1px solid rgba(255, 255, 255, 0.08)',
                }}
              >
                <div>
                  <h4 style={{ fontSize: '1.1rem', color: '#FFFFFF', marginBottom: '0.2rem' }}>{rev.name}</h4>
                  <div style={{ fontSize: '0.8rem', color: '#27C8F5', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                    <ShieldCheck size={13} /> {rev.role}
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span style={{ fontSize: '0.75rem', color: '#A9A6FF', display: 'block' }}>{rev.dives}</span>
                  <span style={{ fontSize: '0.72rem', color: '#7E9BB8' }}>{rev.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
