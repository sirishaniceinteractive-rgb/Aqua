import React from 'react';
import { WingedFish } from './Fish';
import { CoralReef } from './CoralReef';
import { ShieldCheck, Anchor, GraduationCap } from 'lucide-react';

export const AboutSection = () => {
  return (
    <section id="about" className="about-section">
      <div className="container">
        <div className="about-grid">
          {/* Left Column: Photorealistic Winged Exotic Fish */}
          <div className="about-fish-col">
            <WingedFish />
          </div>

          {/* Right Column: Club Information */}
          <div className="about-content-col">
            <span className="section-tag">AQUA SPHERE</span>

            <div className="heading-row-with-badge">
              <h2 className="section-title">О Клубе</h2>
              <span className="since-badge">С 2012 ГОДА</span>
            </div>

            <div className="pink-divider" />

            <p className="about-description">
              Aqua Sphere — это профессиональный дайвинг-клуб, который уже более 10 лет помогает людям
              открывать красоту подводного мира. Мы предлагаем безопасное и комфортное обучение,
              уникальные экскурсии и все необходимое для погружений.
            </p>

            {/* Club Achievements / Metrics */}
            <div className="about-metrics-grid">
              <div className="metric-card">
                <div className="metric-number">12+</div>
                <div className="metric-label">Лет безупречного опыта</div>
              </div>
              <div className="metric-card">
                <div className="metric-number">3,800+</div>
                <div className="metric-label">Сертифицированных дайверов</div>
              </div>
              <div className="metric-card">
                <div className="metric-number">45+</div>
                <div className="metric-label">Уникальных мировых локаций</div>
              </div>
              <div className="metric-card">
                <div className="metric-number">100%</div>
                <div className="metric-label">Стандарты безопасности PADI</div>
              </div>
            </div>

            {/* Club Pillar Features */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: '1rem',
                marginTop: '1.5rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.85rem', color: '#C0D8F0' }}>
                <ShieldCheck size={18} color="#27C8F5" />
                <span>Полная страховка и гид</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.85rem', color: '#C0D8F0' }}>
                <Anchor size={18} color="#F05DBD" />
                <span>Собственная база и флот</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '0.85rem', color: '#C0D8F0' }}>
                <GraduationCap size={18} color="#4DD9ED" />
                <span>Сертификация PADI 5-Star</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Glowing Sea Anemone & Coral at bottom right */}
      <CoralReef variant="about-anemone" />
    </section>
  );
};
