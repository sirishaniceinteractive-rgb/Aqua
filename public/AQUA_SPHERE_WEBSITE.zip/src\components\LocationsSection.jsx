import React, { useState } from 'react';
import { TwoOrangeFish, SwimmingFishSchool, LocationsReefCluster } from './Fish';
import { CoralReef } from './CoralReef';
import { Compass, Waves, Eye, Thermometer } from 'lucide-react';

export const LocationsSection = () => {
  const [selectedLocation, setSelectedLocation] = useState(0);

  const locationsData = [
    {
      title: 'Коралловые рифы Красного моря',
      region: 'Египет (Шарм-эль-Шейх, Дахаб, Рас-Мохаммед)',
      depth: 'до 40 м',
      visibility: '35–45 м',
      temp: '+26°C ... +29°C',
      description: 'Кристальная лазурь, знаменитая Голубая дыра Дахаба и заповедные сады мягких и твердых кораллов с тысячами видов рифовых рыб.',
    },
    {
      title: 'Затонувшие корабли Черного моря',
      region: 'Крым & Кавказское побережье',
      depth: '18–45 м',
      visibility: '15–25 м',
      temp: '+18°C ... +22°C',
      description: 'Исторический рэк-дайвинг: военные корабли, подводные гроты, древние амфоры и загадочные каньоны на дне Черного моря.',
    },
    {
      title: 'Озера и карьеры Подмосковья',
      region: 'Спас-Каменка, Белое Озеро, Сычево',
      depth: '8–25 м',
      visibility: '6–12 м',
      temp: '+14°C ... +20°C',
      description: 'Удобный круглогодичный тренинг, подводный парк артефактов, затопленные леса и комфортная база для отработки глубоких навыков.',
    },
    {
      title: 'Экзотические локации (Таиланд, Индонезия, Мальдивы)',
      region: 'Юго-Восточная Азия & Индийский океан',
      depth: '5–50 м',
      visibility: '40+ м',
      temp: '+28°C ... +31°C',
      description: 'Встречи с гигантскими мантами, китовыми акулами, косяками барракуд и уникальными подводными пещерами мирового класса.',
    },
  ];

  return (
    <section id="locations" className="locations-section">
      <div className="container">
        <div className="locations-grid">
          {/* Left Column: Locations Details */}
          <div className="locations-content-col">
            <span className="section-tag">AQUA SPHERE</span>
            <h2 className="section-title">Локации</h2>
            <div className="pink-divider" />

            <p className="locations-intro">
              Мы организуем погружения в самых живописных местах планеты:
            </p>

            <div className="locations-list">
              {locationsData.map((loc, idx) => (
                <div key={loc.title}>
                  <button
                    className={`location-item-btn ${selectedLocation === idx ? 'active' : ''}`}
                    onClick={() => setSelectedLocation(idx)}
                  >
                    <span className="location-name">
                      <span className="location-bullet-dot" />
                      {loc.title}
                    </span>
                    <span className="location-badge">ПОДРОБНЕЕ</span>
                  </button>

                  {/* Expanded Location Info */}
                  {selectedLocation === idx && (
                    <div
                      style={{
                        padding: '1.2rem 1.4rem',
                        margin: '0.5rem 0 1rem 0',
                        background: 'rgba(3, 19, 47, 0.75)',
                        border: '1px solid rgba(77, 217, 237, 0.25)',
                        borderRadius: '12px',
                        fontSize: '0.9rem',
                        color: '#D1E3F5',
                        lineHeight: 1.6,
                      }}
                    >
                      <div
                        style={{
                          display: 'flex',
                          gap: '1.5rem',
                          flexWrap: 'wrap',
                          marginBottom: '0.8rem',
                          fontSize: '0.82rem',
                          color: '#27C8F5',
                        }}
                      >
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Compass size={14} /> {loc.region}
                        </span>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Waves size={14} /> Глубина: {loc.depth}
                        </span>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Eye size={14} /> Видимость: {loc.visibility}
                        </span>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.35rem' }}>
                          <Thermometer size={14} /> {loc.temp}
                        </span>
                      </div>
                      <p>{loc.description}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Two Orange Fancy Tropical Fish */}
          <div className="locations-fish-col">
            <TwoOrangeFish />
          </div>
        </div>
      </div>

      {/* Swimming Tropical Fish School moving across bottom */}
      <SwimmingFishSchool />

      {/* Reef Fish Cluster with Seagrass & Stones */}
      <LocationsReefCluster />

      {/* Rich Coral Reef Panorama framing the bottom */}
      <CoralReef variant="bottom-panorama" />
    </section>
  );
};
