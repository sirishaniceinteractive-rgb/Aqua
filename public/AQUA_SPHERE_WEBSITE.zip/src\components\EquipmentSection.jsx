import React from 'react';

export const EquipmentSection = () => {
  const items = [
    {
      category: 'ОПТИКА И ЗАЩИТА',
      name: 'Маски и трубки',
      image: './images/equipment/gear_mask.jpg',
      desc: 'Панорамные маски с закаленным стеклом UltraClear, силиконовым обтюратором и широким углом обзора без искажений.',
    },
    {
      category: 'ТЕРМОЗАЩИТА',
      name: 'Гидрокостюмы',
      image: './images/equipment/gear_suit.jpg',
      desc: 'Премиальные неопреновые гидрокостюмы Scubapro и Mares толщиной 3мм, 5мм и 7мм для любых температурных зон.',
    },
    {
      category: 'СИСТЕМА ДЫХАНИЯ',
      name: 'Баллоны и регуляторы',
      image: './images/equipment/gear_tanks.jpg',
      desc: 'Стальные и алюминиевые баллоны 12L / 15L с воздухом и Nitrox, сбалансированные мембранные регуляторы Apeks для холодной воды.',
    },
    {
      category: 'БАЗА И ТРЕНИНГ',
      name: 'Тренировочный комплекс',
      image: './images/equipment/gear_training.jpg',
      desc: 'Собственный глубоководный бассейн 5 метров для отработки навыков, компрессорная станция Bauer и сушильный ангар.',
    },
  ];

  return (
    <section id="equipment" className="equipment-section">
      <div className="container">
        <div style={{ maxWidth: '750px' }}>
          <span className="section-tag">ОСНАЩЕНИЕ И КОМФОРТ</span>
          <h2 className="section-title">Номера и Оборудование</h2>
          <div className="pink-divider" />
          <p style={{ color: '#C4D9F0', fontSize: '1.1rem', fontWeight: 300, lineHeight: 1.7 }}>
            Клуб Aqua Sphere укомплектован топовым снаряжением ведущих мировых брендов.
            Все оборудование проходит обязательное сервисное обслуживание каждые 50 погружений.
          </p>
        </div>

        <div className="equipment-grid">
          {items.map((item, index) => (
            <div key={index} className="equipment-card">
              <div className="equipment-img-wrap">
                <img src={item.image} alt={item.name} className="equipment-img" loading="lazy" />
              </div>
              <div className="equipment-content">
                <span className="equipment-category">{item.category}</span>
                <h3 className="equipment-name">{item.name}</h3>
                <p className="equipment-desc">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
