import React from 'react';
import { ArrowRight, Clock, ShieldCheck, Waves, Award } from 'lucide-react';

export const CoursesSection = ({ onSelectCourse }) => {
  const courses = [
    {
      id: 'beginner',
      title: 'Beginner Diving',
      subtitle: 'Open Water Diver (PADI / CMAS)',
      difficulty: 'Начальный уровень',
      difficultyColor: '#27C8F5',
      duration: '4 дня • 5 погружений',
      depth: 'до 18 метров',
      price: '28 000 ₽',
      image: './images/courses/course_beginner.jpg',
      description:
        'Идеальный старт для новичков. Вы освоите физику погружений, сигналы под водой, управление плавучестью и получите международный бессрочный сертификат.',
      features: [
        'Теория + закрытая вода (бассейн)',
        '4 погружения в открытой воде',
        'Полный комплект фирменной экипировки',
        'Сертификат PADI на всю жизнь',
      ],
    },
    {
      id: 'advanced',
      title: 'Advanced Diving',
      subtitle: 'Advanced Open Water Diver',
      difficulty: 'Продвинутый уровень',
      difficultyColor: '#F05DBD',
      duration: '3 дня • 5 погружений',
      depth: 'до 30 метров',
      price: '34 000 ₽',
      image: './images/courses/course_advanced.jpg',
      description:
        'Расширьте свои границы: глубокие погружения, подводное ориентирование по компасу, ночной дайвинг и оттачивание ювелирной плавучести.',
      features: [
        'Глубоководное погружение (30 м)',
        'Подводная навигация и ориентирование',
        'Ночное погружение с фонарями',
        'Дрифт-дайвинг в течениях (Drift)',
      ],
    },
    {
      id: 'deepsea',
      title: 'Deep Sea Exploration',
      subtitle: 'Deep & Wreck Explorer Spec',
      difficulty: 'Эксперт / Спецкурс',
      difficultyColor: '#A9A6FF',
      duration: '5 дней • 8 погружений',
      depth: 'до 40 метров (Nitrox)',
      price: '46 000 ₽',
      image: './images/courses/course_deepsea.jpg',
      description:
        'Для опытных дайверов, стремящихся к тайнам морского дна: проникновение в затонувшие корабли, использование обогащенного воздуха (Nitrox) и декомпрессия.',
      features: [
        'Рэк-дайвинг (Wreck penetrations)',
        'Сертификация Enriched Air Nitrox',
        'Декомпрессионные протоколы',
        'Подводная видеосъемка 4K в подарок',
      ],
    },
  ];

  return (
    <section id="courses" className="courses-section">
      <div className="container">
        <div className="courses-header">
          <span className="section-tag">ОБУЧЕНИЕ И СЕРТИФИКАЦИЯ</span>
          <h2 className="section-title">Курсы Дайвинга</h2>
          <div className="pink-divider" style={{ width: '120px', margin: '1.2rem auto' }} />
          <p style={{ color: '#C0D5EC', fontSize: '1.1rem', fontWeight: 300, lineHeight: 1.7 }}>
            Международные стандарты PADI и CMAS. Сертифицированные инструкторы высшей категории с 15+ годами практики
            и индивидуальный подход к каждому студенту.
          </p>
        </div>

        <div className="courses-grid">
          {courses.map((course) => (
            <div key={course.id} className="course-card">
              <div className="course-card-image-wrap">
                <img
                  src={course.image}
                  alt={course.title}
                  className="course-card-image"
                  loading="eager"
                  onError={(e) => {
                    // Fallback to high-contrast underwater background gradient
                    e.currentTarget.style.display = 'none';
                  }}
                />
                <span
                  className="course-card-badge"
                  style={{ borderColor: course.difficultyColor, color: course.difficultyColor }}
                >
                  {course.difficulty}
                </span>
              </div>

              <div className="course-card-body">
                <h3 className="course-title">{course.title}</h3>
                <div style={{ color: '#27C8F5', fontSize: '0.88rem', marginBottom: '0.8rem', letterSpacing: '0.04em', fontWeight: 500 }}>
                  {course.subtitle}
                </div>
                <p className="course-desc">{course.description}</p>

                <div className="course-meta-row">
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: '#B5CCE5', fontSize: '0.85rem' }}>
                    <Clock size={15} color="#27C8F5" /> {course.duration}
                  </span>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '0.4rem', color: '#B5CCE5', fontSize: '0.85rem' }}>
                    <Waves size={15} color="#4DD9ED" /> {course.depth}
                  </span>
                  <span style={{ fontWeight: 700, color: '#F05DBD', fontSize: '1.2rem' }}>
                    {course.price}
                  </span>
                </div>

                <ul style={{ listStyle: 'none', marginBottom: '1.6rem', display: 'flex', flexDirection: 'column', gap: '0.55rem' }}>
                  {course.features.map((f, i) => (
                    <li key={i} style={{ fontSize: '0.84rem', color: '#B8D2ED', display: 'flex', alignItems: 'center', gap: '0.55rem' }}>
                      <ShieldCheck size={15} color="#4DD9ED" style={{ flexShrink: 0 }} />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                <button
                  className="course-btn"
                  onClick={() => onSelectCourse && onSelectCourse(course.title)}
                >
                  <span>ЗАПИСАТЬСЯ НА КУРС</span>
                  <ArrowRight size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
