import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { CheckCircle2, AlertCircle, Calendar, User, Mail, Phone, BookOpen, Send } from 'lucide-react';

export const BookingSection = ({ preselectedCourse = '' }) => {
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    course: preselectedCourse || 'Beginner Diving (Open Water Diver)',
    date: '',
    experience: 'Новичок (без опыта)',
    notes: '',
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const errs = {};
    if (!formData.name.trim()) {
      errs.name = 'Пожалуйста, укажите ваше имя';
    }
    if (!formData.contact.trim()) {
      errs.contact = 'Укажите номер телефона или email для связи';
    } else if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.contact) &&
      !/^[\d\+\s\(\)\-]{7,20}$/.test(formData.contact)
    ) {
      errs.contact = 'Введите корректный email или номер телефона';
    }
    if (!formData.date) {
      errs.date = 'Выберите желаемую дату погружения';
    }
    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
        colors: ['#27C8F5', '#4DD9ED', '#F05DBD', '#A9A6FF', '#ffffff'],
      });
    }, 700);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <section id="booking" className="booking-section">
      <div className="container">
        <div className="booking-card-wrapper">
          <div className="booking-card-glow" />

          <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
            <span className="section-tag">БРОНИРОВАНИЕ И КОНСУЛЬТАЦИЯ</span>
            <h2 className="section-title">Откройте подводный мир</h2>
            <div className="pink-divider" style={{ width: '100px', margin: '1rem auto' }} />
            <p style={{ color: '#D4E6FA', fontSize: '1.15rem', fontWeight: 300, maxWidth: '640px', margin: '0 auto' }}>
              Выберите своё первое погружение и отправляйтесь навстречу новым открытиям.
              Наш координатор свяжется с вами в течение 15 минут.
            </p>
          </div>

          {submitted ? (
            <div
              style={{
                textAlign: 'center',
                padding: '3rem 1.5rem',
                background: 'rgba(3, 19, 47, 0.6)',
                borderRadius: '20px',
                border: '1px solid #27C8F5',
              }}
            >
              <CheckCircle2 size={64} color="#27C8F5" style={{ margin: '0 auto 1.5rem auto' }} />
              <h3 style={{ fontSize: '2rem', fontFamily: 'var(--font-serif)', color: '#FFFFFF', marginBottom: '0.8rem' }}>
                Ваша заявка успешно принята!
              </h3>
              <p style={{ color: '#D1E3F5', maxWidth: '520px', margin: '0 auto 1.8rem auto', lineHeight: 1.7 }}>
                Благодарим вас, <strong>{formData.name}</strong>! Мы зарезервировали место на курс{' '}
                <strong>«{formData.course}»</strong> на <strong>{formData.date}</strong>. Инструктор
                свяжется с вами по указанным контактам для уточнения деталей снаряжения.
              </p>
              <button
                className="header-cta-btn"
                onClick={() => {
                  setSubmitted(false);
                  setFormData({
                    name: '',
                    contact: '',
                    course: 'Beginner Diving (Open Water Diver)',
                    date: '',
                    experience: 'Новичок (без опыта)',
                    notes: '',
                  });
                }}
              >
                ОТПРАВИТЬ ЕЩЁ ОДНУ ЗАЯВКУ
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <div className="booking-form-grid">
                {/* Name */}
                <div className="form-group">
                  <label className="form-label" htmlFor="name">
                    Ваше имя *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Например, Александр Воронов"
                    value={formData.name}
                    onChange={handleChange}
                    className="form-input"
                  />
                  {errors.name && (
                    <span style={{ color: '#F05DBD', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                      <AlertCircle size={14} /> {errors.name}
                    </span>
                  )}
                </div>

                {/* Contact (Phone / Email) */}
                <div className="form-group">
                  <label className="form-label" htmlFor="contact">
                    Телефон или Email *
                  </label>
                  <input
                    type="text"
                    id="contact"
                    name="contact"
                    placeholder="+7 (999) 000-00-00 или email"
                    value={formData.contact}
                    onChange={handleChange}
                    className="form-input"
                  />
                  {errors.contact && (
                    <span style={{ color: '#F05DBD', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                      <AlertCircle size={14} /> {errors.contact}
                    </span>
                  )}
                </div>

                {/* Course Selection */}
                <div className="form-group">
                  <label className="form-label" htmlFor="course">
                    Выбор программы или тура
                  </label>
                  <select
                    id="course"
                    name="course"
                    value={formData.course}
                    onChange={handleChange}
                    className="form-select"
                  >
                    <option value="Beginner Diving (Open Water Diver)">Beginner Diving (Open Water Diver)</option>
                    <option value="Advanced Diving (Advanced Open Water)">Advanced Diving (Advanced Open Water)</option>
                    <option value="Deep Sea Exploration (Wreck & Deep)">Deep Sea Exploration (Wreck & Deep)</option>
                    <option value="Индивидуальное пробное погружение (Intro Dive)">Индивидуальное пробное погружение (Intro Dive)</option>
                    <option value="Экспедиция на Красное море">Экспедиция на Красное море</option>
                    <option value="Рэк-экспедиция на Черное море">Рэк-экспедиция на Черное море</option>
                  </select>
                </div>

                {/* Preferred Date */}
                <div className="form-group">
                  <label className="form-label" htmlFor="date">
                    Желаемая дата *
                  </label>
                  <input
                    type="date"
                    id="date"
                    name="date"
                    value={formData.date}
                    onChange={handleChange}
                    className="form-input"
                    min={new Date().toISOString().split('T')[0]}
                  />
                  {errors.date && (
                    <span style={{ color: '#F05DBD', fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                      <AlertCircle size={14} /> {errors.date}
                    </span>
                  )}
                </div>

                {/* Experience */}
                <div className="form-group full-span">
                  <label className="form-label" htmlFor="experience">
                    Ваш текущий опыт в дайвинге
                  </label>
                  <select
                    id="experience"
                    name="experience"
                    value={formData.experience}
                    onChange={handleChange}
                    className="form-select"
                  >
                    <option value="Новичок (без опыта)">Новичок (без опыта — хочу научиться с нуля)</option>
                    <option value="Сертифицирован OWD (до 18м)">Сертифицирован OWD (до 18 метров)</option>
                    <option value="Сертифицирован AOWD (до 30м)">Сертифицирован AOWD (до 30 метров)</option>
                    <option value="Опытный дайвер / Deep / Rescue">Опытный дайвер / Deep / Rescue / Divemaster</option>
                  </select>
                </div>

                {/* Submit Button */}
                <div className="full-span">
                  <button type="submit" className="form-submit-btn" disabled={loading}>
                    {loading ? 'ОТПРАВКА ДАННЫХ...' : 'ЗАПИСАТЬСЯ'}
                  </button>
                  <p className="form-disclaimer">
                    * Нажимая «Записаться», вы соглашаетесь на обработку персональных данных.
                    Форма настроена для демонстрации интерфейса; в рабочей среде подключается защищенный API-обработчик.
                  </p>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
